package factorymethod;

public interface IServico {
    String criar();
    String deletar();
}
