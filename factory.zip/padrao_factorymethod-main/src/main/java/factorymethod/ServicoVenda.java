package factorymethod;

public class ServicoVenda {

    public String criar() {
        return "Pedido de venda criado";
    }

    public String deletar() {
        return "Pedido de venda deletado";
    }
}
